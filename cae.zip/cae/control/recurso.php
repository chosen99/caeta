<?php
session_start();
$bandera = $_POST['bandera'];
if ($bandera == "consulta_alumnos") {
    //include "../../conexion/connexion.php";
    if ($_POST['plantel'] != ""){
        $_SESSION['db_SS'] = 'gcae_'.$_POST['plantel'];
        echo json_encode(1);
    }
    else{
        echo json_encode(0);
    }
    /*$alumnos = new get_data_SS();
    $alumnos->selectASSOC("SELECT AP, AM, Nombre, CURP, Matricula FROM alumnos WHERE Grupo = '$grupo' AND CredencialEstado = 'Sin'");
    $trs='';
    for ($i=0; $i<$alumnos->num_rows; $i++){
        $trs .= '
        <tr>
            <td><button class="btn btn-outline-warning" onclick="autoSet(\''.$alumnos->assoc[$i]['AP'].'\',\''.$alumnos->assoc[$i]['AM'].'\',\''.$alumnos->assoc[$i]['Nombre'].'\',\''.$alumnos->assoc[$i]['CURP'].'\',\''.$alumnos->assoc[$i]['Matricula'].'\',)">'.$alumnos->assoc[$i]['Matricula'].'</button></td>
            <td>'.$alumnos->assoc[$i]['Nombre'].'</td>
            <td>'.$alumnos->assoc[$i]['AP'].'</td>
            <td>'.$alumnos->assoc[$i]['AM'].'</td>
        </tr>';
    }*/

}
elseif ($bandera == "consulta_docentes"){
    //include "../../conexion/connexion.php";
    if ($_POST['plantel'] != ""){
        $_SESSION['db_SS'] = 'gcae_'.$_POST['plantel'];
        echo json_encode(1);
    }
    else{
        echo json_encode(0);
    }
    /*$alumnos = new get_data_SS();
    $alumnos->selectASSOC("SELECT AP, AM, Nombre, CURP, Matricula FROM alumnos WHERE Grupo = '$grupo' AND CredencialEstado = 'Sin'");
    $trs='';
    for ($i=0; $i<$alumnos->num_rows; $i++){
        $trs .= '
        <tr>
            <td><button class="btn btn-outline-warning" onclick="autoSet(\''.$alumnos->assoc[$i]['AP'].'\',\''.$alumnos->assoc[$i]['AM'].'\',\''.$alumnos->assoc[$i]['Nombre'].'\',\''.$alumnos->assoc[$i]['CURP'].'\',\''.$alumnos->assoc[$i]['Matricula'].'\',)">'.$alumnos->assoc[$i]['Matricula'].'</button></td>
            <td>'.$alumnos->assoc[$i]['Nombre'].'</td>
            <td>'.$alumnos->assoc[$i]['AP'].'</td>
            <td>'.$alumnos->assoc[$i]['AM'].'</td>
        </tr>';
    }*/

}
elseif ($bandera == "get_info_edita_alumno"){
    $id = $_POST['id'];
    include "../../conexion/connexion.php";
    $consulta = new con_dinamic_db();
    $consulta->selectASSOC("SELECT id, Matricula, AP, AM, Nombre, CURP, Grupo, Especialidad, Generacion, Foto, Firma FROM alumnos WHERE id = '$id'");
    echo json_encode($consulta->assoc);
}
elseif ($bandera == "seve_update"){
    $id = $_POST['id_save'];
    include "../../conexion/connexion.php";
    $sql = new con_dinamic_db();
    $matri = $_POST['matri'];
    $ap = $_POST['AP'];
    $am = $_POST['AM'];
    $nom = $_POST['Nombre'];
    $curp = $_POST['CURP'];
    $grupo = $_POST['Grupo'];
    $espe = $_POST['Especialidad'];
    $gene = $_POST['Generacion'];
    $sql->simpleSQL("UPDATE alumnos SET Matricula = '$matri', AP = '$ap', AM = '$am', Nombre = '$nom', CURP = '$curp', Grupo = '$grupo', Especialidad = '$espe', Generacion = '$gene' WHERE id = '$id'");
    echo json_encode($id);
}