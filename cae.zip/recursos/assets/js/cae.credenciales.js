/*$(document).on("click", ".consulta_n2", function (e){
    e.preventDefault();
    if ($("#grupo_nuevos").val() !== null){
        $('#grupo_nuevos').val(false);
    }
})

$(document).on("click",".consulta_n",function (){
    $("#nuevos").validate({
        rules:{
            plantel_nuevos: "required",
            grupo_nuevos: "required"
        },
        messages: {
            plantel_nuevos: "Por favor, seleccione su plantel",
            grupo_nuevos: "Por favor, seleccione un grupo",
        },
        submitHandler: function() {
            $("#nu").css("display","block");
        }
    });
}); */

$(document).ready(function () {
    w3.includeHTML(init);
});

function init() {
    $('#menu-lat').BootSideMenu({
        side: "right",
        width: "37%",
        autoClose: true,
        pushBody: false,
        remember: false
    });
}

function getplantel(p){
    let form = new FormData();
    form.append('plantel',p);
    form.append('bandera','consulta_alumnos');
    fetch('./recurso.php', {
        method: 'POST',
        cache: "no-cache",
        body: form
    }).then(res => res.json())
        .then(res => {
            if (res === 1){
                $("#alumnos").DataTable({
                    language: {
                        url: "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
                    },
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
                    "sAjaxSource": "./SS/alumnos_vista_credenciales.php",
                    "columnDefs":[
                        {
                            targets: [0],
                            render: function (data, type, row){
                                return '<input class="m-auto" type="checkbox" name="seleciones[]">'
                            }
                        },
                        {
                            targets: [1],
                            render: function (data, type, row){ <!-- +row[2]+','+row[3]+','+row[1]+','+row[4]+','+row[0]+ -->
                                return '<div class="tooltip_foto nombre_tabla'+row[10]+'">'+row[0]+' '+row[1]+' '+row[2]+'<span class="tooltiptext"><img src="https://images.freeimages.com/images/previews/ac9/railway-hdr-1361893.jpg" alt="foto-" width="120"></span></div>';
                            }
                        },
                        {
                            targets: [2],
                            render: function (data, type, row){
                                return '<span>'+row[3]+'</span>'
                            }
                        },
                        {
                            targets: [3],
                            render: function (data, type, row){
                                return row[4]
                            }
                        },
                        {
                            targets: [4],
                            render: function (data, type, row){
                                return row[5]
                            }
                        },
                        {
                            targets: [5],
                            render: function (data, type, row){
                                return row[6]
                            }
                        },
                        {
                            targets: [6],
                            render: function (data, type, row){
                                return row[7]
                            }
                        },
                        {
                            targets: [7],
                            render: function (data, type, row){
                                return row[8]
                            }
                        },
                        {
                            targets: [8],
                            render: function (data, type, row){
                                let color = '';
                                if (row[9] === "Sin"){
                                    color = '<span style="width: 32px; height: 32px; border-radius: 50%;">S</span>';
                                }
                                return row[9]
                            }
                        },
                        {
                            visible: false,
                            targets: [9]
                        },
                        {
                            targets: [-1],
                            render: function (data, type, row){
                                return '<button class="clase_edita" style="border: none; background: none;" value="'+row[10]+'" data-bs-toggle="modal" data-bs-target="#editar"><img src="../../recursos/img/svg/edit.svg" alt="editar" width="32"></button>' +
                                       '<span class="boton-p" data-bs-toggle="modal" data-bs-target="#foto"><img src="../../recursos/img/svg/camera.svg" alt="foto" width="32"></span>' +
                                       '<span class="boton-p" data-bs-toggle="modal" data-bs-target="#codigo"><img src="../../recursos/img/svg/code.svg" alt="codigo" width="32"></span>' +
                                       '<span class="boton-p" data-bs-toggle="modal" data-bs-target="#imprimir"><img src="../../recursos/img/svg/print.svg" alt="impresion" width="32"></span>' +
                                       '<span class="boton-p" data-bs-toggle="modal" data-bs-target="#CA">CA</span>' +
                                       '<span class="boton-p" data-bs-toggle="modal" data-bs-target="#eliminar"><img src="../../recursos/img/svg/delete.svg" alt="eliminar" width="32"></span>'
                            }
                        }
                    ]
                });
            }
        });
}

$(document).on('click', '.elimina_foto_alumno', function (e){
    e.preventDefault();
    /*Swal.fire({
        title: '¿Estas seguro de querer eliminar esta foto?',
        showDenyButton: false,
        showCancelButton: true,
        confirmButtonText: 'SI',
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire('Saved!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Changes are not saved', '', 'info')
        }
    })*/
})

$(document).on('click', '.clase_edita', function (){
    let id = $(this).val();
    let form = new FormData();
    form.append('bandera','get_info_edita_alumno');
    form.append('id', id);
    fetch('./recurso.php',{
        method: 'POST',
        body: form
    }).then(res => res.json()).then(res =>{
        if(res['Matricula'] !== ""){
            $("#id_save").val(res['id']);
            $("#matri").val(res['Matricula']);
            $("#AP").val(res['AP']);
            $("#AM").val(res['AM']);
            $("#Nombre").val(res['Nombre']);
            $("#CURP").val(res['CURP']);
            $("#Grupo").val(res['Grupo']);
            $("#Especialidad").val(res['Especialidad']);
            $("#Generacion").val(res['Generacion']);
            /*$("#get_fo").val(res['Foto']);
            $("#get_fi").val(res['Firma']);*/
        }
    })
})

$(document).on('click', '.save_update', function (e){
    $('#editar').modal('toggle');
    e.preventDefault();
    let form = new  FormData(document.getElementById('edita_alumno'));
    form.append('bandera','seve_update')
    fetch('./recurso.php',{
        method: 'POST',
        body: form
    }).then(res => res.json()).then(res => {
        $('.nombre_tabla'+res).html($("#AP").val()+ ' ' + $("#AM").val()+' '+$("#Nombre").val())
        Swal.fire({
            title: 'Su información se ha guardado correctamente.',
            showDenyButton: false,
            showConfirmButton: false
        })
        setTimeout(() => {
            Swal.close();
        }, "1500");
    })
})